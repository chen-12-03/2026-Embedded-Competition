/*
  5A量程（185mV/A）：ACS712_xxA = 0.185
  20A量程（100mV/A）：ACS712_xxA = 0.100
  30A量程（66mV/A）：ACS712_xxA = 0.066
  40A量程（50mV/A）：ACS712_xxA = 0.050
  50A量程（40mV/A）：ACS712_xxA = 0.040
*/
const float ACS712_xxA = 0.185; // 根据模块量程版本修改正确的值，这里使用的是5A量程的模块，所以值0.185
int Vout = A1; 
void setup() {
  Serial.begin(9600);
}

void loop() {
  float current = 0;           // 电流值
  const int numSamples = 20;   // 外层采样次数
  const int numReadings = 50;  // 每次采样中的读数次数

  // 进行多次采样，减少噪声
  for (int j = 0; j < numSamples; j++) {
    long rawValue = 0;  // 存储每次读取的总和
    // 每次采样 50 次并取平均值
    for (int i = 0; i < numReadings; i++) {
      rawValue += analogRead(Vout);
    }

    rawValue /= numReadings;  // 计算平均值
    // 计算电流：将 ADC 值转化为电流值
    current += ((5.0 / 1024.0 * rawValue - 2.50) / ACS712_xxA);
  }

  // 计算最终平均电流值
  current /= numSamples;

  // 打印电流值
  Serial.println(current);

  // 延时 100ms
  delay(100);
}
